export interface ScreeningProps {
    screeningId: string;
    movieId: string;
    cinemaId: string;
    roomId: string;
    date: string;
    time: string;
}
