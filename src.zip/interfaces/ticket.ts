export interface Ticket {
  ticketId: string;
  userId: string;
  screeningId: string;
  seatId: string;
  purchaseTime: string;
}
